Instructions
------------
simply run the script, enter the name of the csv you wish to use when prompted

Note
-----------
I was not able to test this due to issues rendering a csv test file.
The code however, should be 99% accurate. 
Let me know if you want me to get a proper csv file

Thank you,
Matt Wilson
(954)-856-1174

